
interface Film {
  id : number ;
  title : string ;
  director : string ;
  duration : number ;
  budget? : number ;
  description? : string ;
  imageUrl? : string ;
}

type NewFilm = Omit<Film, "id">; //prend le type film mais enlève la propriété id

export type {Film, NewFilm};
